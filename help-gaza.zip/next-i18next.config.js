module.exports = {
  i18n: {
    defaultLocale: 'fa',
    locales: ['fa', 'en'],
    localeDetection: true,
  },
};